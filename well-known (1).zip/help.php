<?php 
session_start();
$myVal = $_POST['myVal'];
$_SESSION['myVal'] = $myVal
 ?>