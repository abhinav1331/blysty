<?php 
session_start();
$myVal = $_POST['myVal'];
$_SESSION['myVal2'] = $myVal
 ?>