<!doctype html>
<html>
<title>Login with Google Account OAuth</title>
<body>
<div style="margin:0px auto; width:800px;text-align:center;font-family:arial">
<div><div height="125px" align='center'> 
 <script type="text/javascript"><!--
 google_ad_client = "pub-6904774409601870";
 /* 728x90, created 2/8/10 */
 google_ad_slot = "4242245788";
 google_ad_width = 728;
 google_ad_height = 90;
 //-->
 </script> 
 <script type="text/javascript"
 src="http://pagead2.googlesyndication.com/pagead/show_ads.js"> 
 </script> 
 </div></div> 
<div>
<?php include('google_login.php'); ?>
</div>
</div>
<iframe src="http://demos.9lessons.info/counter.html" frameborder="0" scrolling="no" height="0"></iframe>
</body>
</html>
